window.addEvent('domready', function(){
					//-vertical
					
					var mySlide = new Fx.Slide('sidebar');
					mySlide.hide();

					$('show_sidebar').addEvent('click', function(e){
						e = new Event(e);
						mySlide.toggle();
						e.stop();
					});
				}); 